import { Component, EnvironmentInjector, inject } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { triangle, ellipse, square } from 'ionicons/icons';
import { Router } from '@angular/router';
@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
  standalone: true,
  imports: [IonicModule],
})
export class TabsPage {
  private router = inject(Router);
  public environmentInjector = inject(EnvironmentInjector);

  constructor() {
    this.redirigirUsuario();
    addIcons({ triangle, ellipse, square });
  }
  redirigirUsuario() {
    const rol = localStorage.getItem('userRol');
    if (rol === 'colaborador') {
      // Redirigimos a la pestaña de tareas directamente
      this.router.navigate(['/tabs/tab2']);
    }
  }
}
