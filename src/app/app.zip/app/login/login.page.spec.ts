// Importaciones de las herramientas de prueba de Angular
import { ComponentFixture, TestBed } from '@angular/core/testing';
// Importamos el componente que vamos a probar
import { LoginPage } from './login.page';

// 'describe' define una suite de pruebas para el componente LoginPage
describe('LoginPage', () => {
  let component: LoginPage;          // Referencia a la clase del componente
  let fixture: ComponentFixture<LoginPage>; // Referencia al entorno de renderizado del componente

  // 'beforeEach' se ejecuta ANTES de cada prueba individual
  beforeEach(() => {
    // TestBed configura el módulo de pruebas para que simule el navegador
    fixture = TestBed.createComponent(LoginPage);
    component = fixture.componentInstance; // Instancia de la lógica del componente
    fixture.detectChanges();               // Dispara la detección de cambios (renderiza el HTML)
  });

  // 'it' define una prueba específica
  it('should create', () => {
    // Esta prueba simplemente verifica que el componente cargue correctamente y no sea nulo
    expect(component).toBeTruthy();
  });
});