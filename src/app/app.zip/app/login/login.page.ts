import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; // Permite la navegación entre páginas.
import { CommonModule } from '@angular/common'; // Directivas básicas de Angular (como *ngIf).
import { FormsModule } from '@angular/forms'; // Habilita el uso de [(ngModel)] en formularios.

// Importación de componentes específicos de Ionic para optimizar el rendimiento (Standalone).
import { IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, IonInput, IonButton } from '@ionic/angular/standalone';

// Herramientas de Firebase para manejar la seguridad y autenticación.
import { Auth } from '@angular/fire/auth'; 
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, getAuth } from 'firebase/auth';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login', // Nombre de la etiqueta HTML personalizada.
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true, // Indica que el componente se gestiona a sí mismo sin necesidad de un AppModule.
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, 
    IonInput, IonButton, CommonModule, FormsModule, RouterLink]
})
export class LoginPage implements OnInit {
  // Variables vinculadas al formulario mediante Double Data Binding (ngModel).
  email: string = '';
  password: string = '';

  // Inyectamos el Router para movernos de página y Auth para la sesión.
  constructor(private router: Router, private auth: Auth) { }

  ngOnInit() {
    // Se ejecuta al cargar la página (actualmente vacío).
  }

  /**
   * MÉTODO DE INICIO DE SESIÓN
   * Se comunica con Firebase para validar las credenciales del usuario.
   */
  login() {
    // Impresiones de diagnóstico en consola para verificar los datos antes de enviar.
    console.log('login', this.email, this.password);
    
    // Llamada asíncrona a Firebase.
    signInWithEmailAndPassword(getAuth(), this.email, this.password)
      .then(() => {
        // Si los datos son correctos, navegamos al Panel de Control (Tab1).
        this.router.navigate(['/tabs/tab1']);
      })
      .catch((err) => {
        // Si hay un error (ej. contraseña incorrecta), se captura y muestra un mensaje.
        console.error('Login error', err);
        alert('Error al iniciar sesión: ' + err.message);
      });
  }

  /**
   * MÉTODO DE REGISTRO RÁPIDO
   * Crea un nuevo usuario directamente desde la pantalla de login.
   */
  register() {
    // Intenta crear el usuario en la base de datos de Firebase Auth.
    createUserWithEmailAndPassword(getAuth(), this.email, this.password)
      .then(() => {
        // Si se crea con éxito, entra directamente a la aplicación.
        this.router.navigate(['/tabs/tab1']);
      })
      .catch((err) => {
        // Muestra el error técnico en caso de fallo (ej. correo ya registrado).
        console.error('Register error', err);
        alert('Error al crear cuenta: ' + err.message);
      });
  }
}