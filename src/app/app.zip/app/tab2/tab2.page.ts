import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

// Firebase
import { Firestore, collection, addDoc, query, where, orderBy, collectionData } from '@angular/fire/firestore';
import { Auth, signOut } from '@angular/fire/auth';
import { Observable } from 'rxjs';
import { addIcons } from 'ionicons';
import { folder, folderOpen, briefcaseOutline, logOutOutline } from 'ionicons/icons';

// Ionic Standalone
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonLabel,
  IonDatetimeButton, IonModal, IonDatetime, IonSelect, IonSelectOption,
  IonButton, IonFooter, IonIcon, IonInput, IonTextarea, IonFab, IonFabButton, IonBadge,
  IonAvatar,
  IonButtons, IonCard, IonProgressBar, IonRow, IonGrid, IonCol, IonText,
} from '@ionic/angular/standalone';
import { IonicModule } from "@ionic/angular";
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule,
    // Componentes de Estructura
    IonHeader, IonToolbar, IonTitle, IonContent, IonFooter,
    // Componentes de Interfaz
    IonButtons, IonAvatar, IonBadge, IonCard, IonItem, IonLabel, IonList,
    IonIcon, IonButton, IonProgressBar, IonText,
    IonGrid, IonRow, IonCol,
    // Componentes de Acción
    IonFab, IonFabButton
  ]
})  
export class Tab2Page implements OnInit {
  agregarProyecto() {
    console.log('Abriendo formulario para nuevo proyecto...');
    // Aquí puedes llamar a un AlertController o abrir un Modal
  }
  gestionarTarea(proyecto: any, tarea: any, indice: number) {
    console.log(`Gestionando tarea: ${tarea.nombre} del proyecto ${proyecto.nombre}`);
    // Aquí podrías marcar la tarea como completada o eliminarla
  }
  toggleProyecto(proyecto: any) {
    // Simplemente cambia el valor booleano al opuesto
    proyecto.abierto = !proyecto.abierto;
  }
  // Variables del formulario
  tituloTarea: string = '';
  descripcionTarea: string = '';
  prioridadTarea: string = 'medium';
  notaTarea: string = '';
  usuarioAsignado: string = '';

  // Inyección de servicios
  private firestore: Firestore = inject(Firestore);
  private auth: Auth = inject(Auth);
  private router: Router = inject(Router);

  // Observable para las tareas
  tareas$: Observable<any[]> | undefined;
  rolUsuario: any;
  proyectos: any;

  constructor() {
  addIcons({ folder, folderOpen, briefcaseOutline, logOutOutline });
}

  ngOnInit() {
    const userEmail = this.auth.currentUser?.email;
    if (userEmail) {
      const dbRef = collection(this.firestore, 'tareas');

      // FILTRO: Solo tareas donde el usuario es el ASIGNADO (Vista Colaborador)
      const q = query(
        dbRef,
        where('asignadoA', '==', userEmail),
        orderBy('fecha', 'desc')
      );

      this.tareas$ = collectionData(q, { idField: 'id' }) as Observable<any[]>;
    }
  }
   cargarDatos() {
    // 1. Detectar el rol guardado en localStorage.
    const rolGuardado = localStorage.getItem('userRol');
    // Si no existe un rol, se asigna 'colaborador' por seguridad (principio de menor privilegio).
    this.rolUsuario = rolGuardado || 'colaborador';

    // 2. Cargar los proyectos guardados previamente.
    const datosProyectos = localStorage.getItem('proyectos_taskflow');
    if (datosProyectos) {
      // Convierte la cadena de texto JSON nuevamente en un arreglo de objetos.
      this.proyectos = JSON.parse(datosProyectos);
    }
  }

  async addTarea() {
    if (this.tituloTarea.trim() === '') return;

    try {
      const dbRef = collection(this.firestore, 'tareas');
      await addDoc(dbRef, {
        titulo: this.tituloTarea,
        descripcion: this.descripcionTarea,
        prioridad: this.prioridadTarea,
        nota: this.notaTarea,
        asignadoA: this.usuarioAsignado,
        creadoPor: this.auth.currentUser?.email || 'Anónimo',
        estado: 'En proceso',
        fecha: new Date().toISOString()
      });

      this.resetForm();
      console.log("Tarea guardada con éxito.");
    } catch (e) {
      console.error("Error al guardar en Firebase:", e);
    }
  }

  resetForm() {
    this.tituloTarea = '';
    this.descripcionTarea = '';
    this.notaTarea = '';
    this.usuarioAsignado = '';
  }

  async logout() {
    try {
      await signOut(this.auth);
      this.router.navigate(['/login']);
    } catch (e) {
      console.error("Error al cerrar sesión:", e);
    }
  }
}