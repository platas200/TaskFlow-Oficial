import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  imports: [IonicModule, ExploreContainerComponent],
})
export class Tab3Page {
  router: any;
  constructor() {}
  logout() {
  localStorage.removeItem('userRol'); // Borramos el rol
  this.router.navigate(['/login']);    // Regresamos al inicio
}
}

