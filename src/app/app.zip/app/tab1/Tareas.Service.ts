import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs'; // Importamos la "estación de radio"

@Injectable({
  providedIn: 'root' // Esto hace que el servicio esté disponible en toda la app
})
export class TareasService {

  // 1. Creamos el emisor de mensajes. 
  // Empezamos en 'false' porque al abrir la app no hay nada que refrescar aún.
  private refreshSource = new BehaviorSubject<boolean>(false);

  // 2. Exponemos el emisor como un "Observable". 
  // Esto permite que la Tab 1 se "suscriba" para escuchar los cambios.
  refresh$ = this.refreshSource.asObservable();

  // 3. Este es el botón que presionará la Tab 2.
  // Cuando se llame a esta función, se le enviará un 'true' a todos los oyentes.
  triggerRefresh() {
    this.refreshSource.next(true);
  }
}