import { Component, OnInit, inject, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';

// Firebase
import { Firestore, collection, query, where, orderBy, collectionData, addDoc } from '@angular/fire/firestore';
import { Auth, onAuthStateChanged, signOut } from '@angular/fire/auth';
import { Storage, ref, uploadBytes, getDownloadURL } from '@angular/fire/storage';
import { updateProfile } from '@angular/fire/auth';

import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem,
  IonLabel, IonBadge, IonIcon, IonProgressBar, IonButtons, IonAvatar,
  IonCard, IonCol, IonGrid, IonButton, IonFabButton,
  IonFab, IonRow, IonText, IonModal, IonDatetime, AlertController,
  IonDatetimeButton, IonSelect, IonSelectOption, IonTextarea, IonInput
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { Router } from '@angular/router';
import {
  folder, folderOpen, briefcase, briefcaseOutline, add,
  timeOutline, flash, addCircleOutline, saveOutline, logOutOutline, camera
} from 'ionicons/icons';



@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    // Componentes de Estructura y UI
    IonHeader, IonToolbar, IonTitle, IonContent, IonList, IonItem,
    IonLabel, IonBadge, IonIcon, IonProgressBar, IonButtons, IonAvatar,
    IonCard, IonCol, IonGrid, IonButton, IonFab, IonFabButton, IonRow, IonText,
    IonModal,
    // Componentes de Formulario 
    IonDatetime,
    IonDatetimeButton,
    IonSelect,
    IonSelectOption,
    IonTextarea,
    IonInput
  ],
})
export class Tab1Page implements OnInit {
  proyectoSeleccionado: any;
  perfilModal: any;
  private router = inject(Router);
  private storage = inject(Storage);

  abrirModalTarea(proyecto: any) {
    this.proyectoSeleccionado = proyecto;
    this.modal.present();
  }
  cerrarModal() {
    this.modal.dismiss();
    this.resetForm();
  }
  async logout() {
    try {
      await signOut(this.auth); // Cierra sesión en Firebase
      localStorage.removeItem('userRol'); // Limpia el rol guardado
      this.router.navigate(['/login']); // Redirige a la pantalla de login
      console.log('Sesión cerrada con éxito');
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  }
  async subirImagen(event: any) {
  const file = event.target.files[0];
  if (!file) return;

  const user = this.auth.currentUser;
  if (user) {
    try {
      const imgRef = ref(this.storage, `perfiles/${user.uid}`);
      await uploadBytes(imgRef, file);
      const url = await getDownloadURL(imgRef);
      
      // 1. Actualizamos Firebase
      await updateProfile(user, { photoURL: url });
      
      // 2. ACTUALIZACIÓN CRÍTICA: Forzamos el cambio en la variable local
      this.fotoPerfil = url; 
      
      console.log('URL actualizada:', url);
    } catch (error) {
      console.error(error);
    }
  }
}
  // Variables de estado
  @ViewChild(IonModal) modal!: IonModal;
  rolUsuario: string = '';
  tareas$!: Observable<any[]>;
  descripcionTarea: any;
  tituloTarea: any;
  usuarioAsignado: any;
  prioridadTarea: any;
  notaTarea: any;
  public fotoPerfil: string | null = null;
  ngOnInit() {
    this.fotoPerfil = this.auth.currentUser?.photoURL || null;
    // 1. Cargamos datos locales primero
    this.cargarDatos();

    // 2. Escuchamos al usuario de Firebase de forma segura
    onAuthStateChanged(this.auth, (user) => {
      if (user && user.email) {
        const dbRef = collection(this.firestore, 'tareas');

        // FILTRO: Solo tareas creadas por el líder actual
        const q = query(
          dbRef,
          where('creadoPor', '==', user.email),
          orderBy('fecha', 'desc')
        );

        // Asignamos el flujo de datos de Firebase al observable
        this.tareas$ = collectionData(q, { idField: 'id' }) as Observable<any[]>;
      } else {
        console.warn("Tab1: Esperando autenticación de Firebase...");
      }
    });
  }

  ionViewWillEnter() {
    this.cargarDatos();
  }
  async addTarea() {
    // Validación básica: Si no hay título, no hace nada
    if (!this.tituloTarea || this.tituloTarea.trim() === '') {
      console.warn("El título de la tarea es obligatorio");
      return;
    }

    try {
      const dbRef = collection(this.firestore, 'tareas');

      // Guardamos el objeto en Firestore
      await addDoc(dbRef, {
        titulo: this.tituloTarea,
        descripcion: this.descripcionTarea || '',
        prioridad: this.prioridadTarea || 'medium',
        nota: this.notaTarea || '',
        asignadoA: this.usuarioAsignado || 'Sin asignar',
        creadoPor: this.auth.currentUser?.email || 'Anónimo',
        estado: 'En proceso',
        fecha: new Date().toISOString()
      });

      console.log("Tarea guardada en Firebase con éxito.");
      this.resetForm(); // Limpiamos los inputs del modal

    } catch (e) {
      console.error("Error al guardar en Firebase:", e);
    }
  }

  // Función que une el guardado con el cierre del modal
  async guardarTareaYSalir() {
    await this.addTarea();
    this.modal.dismiss(); // Esto cierra el modal automáticamente
  }

  // Función para limpiar los campos del formulario
  resetForm() {
    this.tituloTarea = '';
    this.descripcionTarea = '';
    this.prioridadTarea = 'medium';
    this.notaTarea = '';
    this.usuarioAsignado = '';
  }
  // Recupera el rol y los proyectos desde la memoria del navegador/dispositivo.
  cargarDatos() {
    // 1. Detectar el rol guardado en localStorage.
    const rolGuardado = localStorage.getItem('userRol');
    // Si no existe un rol, se asigna 'colaborador' por seguridad (principio de menor privilegio).
    this.rolUsuario = rolGuardado || 'colaborador';

    // 2. Cargar los proyectos guardados previamente.
    const datosProyectos = localStorage.getItem('proyectos_taskflow');
    if (datosProyectos) {
      // Convierte la cadena de texto JSON nuevamente en un arreglo de objetos.
      this.proyectos = JSON.parse(datosProyectos);
    }
  }

  // Arreglo de objetos que representa los proyectos y sus tareas internas.
  proyectos: any[] = [
    {
      id: 1,
      nombre: 'Desarrollo TaskFlow',
      cliente: 'UNISTMO',
      progreso: 0.6,
      abierto: true, // Controla si la lista de tareas está visible (acordeón).
      tareas: [
        { nombre: 'Configurar Firebase', fecha: 'Hoy', prioridad: 'Alta', clase: 'prioridad-alta' }
      ]
    }
  ];

  // Inyectamos AlertController en el constructor para poder crear diálogos.
  constructor(
    private firestore: Firestore = inject(Firestore),
    public auth: Auth = inject(Auth),
    private alertCtrl: AlertController = inject(AlertController) // Asegúrate que diga AlertController
  ) {
    addIcons({ camera, logOutOutline, addCircleOutline, saveOutline, briefcaseOutline, flash, timeOutline, add, folder, folderOpen, briefcase });
  }

  // Alterna el estado de visibilidad del proyecto (expandir/colapsar).
  toggleProyecto(proyecto: any) {
    proyecto.abierto = !proyecto.abierto;
  }

  // Función asíncrona para crear un nuevo proyecto mediante una alerta con inputs.
  async agregarProyecto() {
    const alert = await this.alertCtrl.create({
      header: 'Nuevo Proyecto',
      inputs: [
        { name: 'nombre', type: 'text', placeholder: 'Nombre del proyecto' },
        { name: 'cliente', type: 'text', placeholder: 'Cliente' }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Crear',
          handler: (data: { nombre: any; cliente: any; }) => {
            // Inserta el nuevo proyecto en el arreglo local.
            this.proyectos.push({
              id: this.proyectos.length + 1,
              nombre: data.nombre || 'Nuevo Proyecto',
              cliente: data.cliente || 'Sin cliente',
              progreso: 0,
              abierto: true,
              tareas: []
            });
            // Guarda los cambios en el almacenamiento persistente.
            this.guardarEnStorage();
          }
        }
      ]
    });
    await alert.present(); // Muestra la alerta en pantalla.
  }

  // Función asíncrona para añadir tareas a un proyecto específico.
  async agregarTarea(proyecto: any) {
    const alert = await this.alertCtrl.create({
      header: 'Detalles de la Tarea',
      inputs: [
        { name: 'tarea', type: 'text', placeholder: 'Nombre de la tarea' },
        { name: 'fecha', type: 'date' },
        // Opciones de radio para definir la urgencia.
        { type: 'radio', label: 'Alta Prioridad', value: 'Alta', name: 'prioridad', checked: true },
        { type: 'radio', label: 'Baja Prioridad', value: 'Baja', name: 'prioridad' }
      ],
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Guardar',
          handler: (data: { tarea: any; fecha: any; prioridad: string; }) => {
            if (data.tarea) {
              // Agrega el objeto tarea al sub-arreglo del proyecto correspondiente.
              proyecto.tareas.push({
                nombre: data.tarea,
                fecha: data.fecha || 'Sin fecha',
                prioridad: data.prioridad,
                // Asigna una clase CSS dinámica según la prioridad seleccionada.
                clase: data.prioridad === 'Alta' ? 'prioridad-alta' : 'prioridad-baja',
                completada: false
              });
              this.guardarEnStorage(); // Actualiza el almacenamiento local.
            }
          }
        }
      ]
    });
    await alert.present();
  }

  // Permite al líder cambiar el estado de la tarea (completada/proceso) o borrarla.
  async gestionarTarea(proyecto: any, tarea: any, index: number) {
    const alert = await this.alertCtrl.create({
      header: 'Gestionar Tarea',
      message: `¿Qué deseas hacer con "${tarea.nombre}"?`,
      buttons: [
        {
          // El texto cambia dinámicamente según el estado actual de la tarea.
          text: tarea.completada ? 'Marcar como En Proceso' : 'Marcar como Completada',
          handler: () => {
            tarea.completada = !tarea.completada; // Invierte el valor booleano.
            this.guardarEnStorage();
          }
        },
        {
          text: 'Eliminar Tarea',
          role: 'destructive', // Indica que es una acción crítica (se pinta de rojo).
          cssClass: 'danger',
          handler: () => {
            proyecto.tareas.splice(index, 1); // Elimina el elemento del arreglo usando su índice.
            this.guardarEnStorage();
          }
        },
        { text: 'Cerrar', role: 'cancel' }
      ]
    });
    await alert.present();
  }

  // Función para persistir el arreglo de proyectos en la memoria local (localStorage).
  guardarEnStorage() {
    // Los datos deben convertirse a String para ser almacenados.
    localStorage.setItem('proyectos_taskflow', JSON.stringify(this.proyectos));
  }

  // Función para recuperar y parsear los datos de proyectos al iniciar la app.
  cargarDeStorage() {
    const datos = localStorage.getItem('proyectos_taskflow');
    if (datos) {
      this.proyectos = JSON.parse(datos); // Convierte el String de vuelta a objeto JS.
    }
  }
}