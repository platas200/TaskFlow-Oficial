import { Injectable, inject } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Auth } from '@angular/fire/auth';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  private auth = inject(Auth);
  private router = inject(Router);
canActivate(): Promise<boolean> {
    const current = this.auth.currentUser;
    const rol = localStorage.getItem('userRol');

    // 1. Si ya tenemos usuario e intenta ir a la raíz, redirigimos por rol
    if (current) {
      this.redirigirPorRol(rol);
      return Promise.resolve(true);
    }

    return new Promise<boolean>((resolve) => {
      import('firebase/auth').then(({ onAuthStateChanged }) => {
        onAuthStateChanged(this.auth as any, (user) => {
          if (user) {
            // 2. Al inicializar, verificamos el rol guardado
            const rolActualizado = localStorage.getItem('userRol');
            this.redirigirPorRol(rolActualizado);
            resolve(true);
          } else {
            this.router.navigate(['/login']);
            resolve(false);
          }
        });
      }).catch(() => {
        this.router.navigate(['/login']);
        resolve(false);
      });
    });
  }

  // Método auxiliar para manejar la lógica de redirección
  private redirigirPorRol(rol: string | null) {
    // Si es colaborador y la URL actual no es ya la tab2, lo movemos
    if (rol === 'colaborador' && !this.router.url.includes('tab2')) {
      this.router.navigate(['/tabs/tab2']);
    } 
    // Si es líder y está en una ruta genérica, lo mandamos a su panel
    else if (rol === 'lider' && this.router.url === '/') {
      this.router.navigate(['/tabs/tab1']);
    }
  }
}
