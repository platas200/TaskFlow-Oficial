import { Injectable, inject } from '@angular/core';
import {
  Firestore,
  collection,
  collectionData,
  addDoc,
  doc,
  updateDoc,
  deleteDoc,
  query,
  where,
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';

export interface Task {
  id?: string;
  title: string;
  body?: string;
  ownerId?: string;
  updatedAt?: any;
}

@Injectable({ providedIn: 'root' })
export class TaskService {
  private firestore: Firestore = inject(Firestore);
  private collectionName = 'tareas';

  getTasks(ownerId?: string): Observable<Task[]> {
    const colRef = collection(this.firestore, this.collectionName);
    if (ownerId) {
      const q = query(colRef, where('ownerId', '==', ownerId));
      return collectionData(q, { idField: 'id' }) as Observable<Task[]>;
    }
    return collectionData(colRef, { idField: 'id' }) as Observable<Task[]>;
  }

  async createTask(task: Task) {
    const colRef = collection(this.firestore, this.collectionName);
    const now = new Date();
    return addDoc(colRef, { ...task, updatedAt: now });
  }

  async updateTask(id: string, data: Partial<Task>) {
    const docRef = doc(this.firestore, `${this.collectionName}/${id}`);
    return updateDoc(docRef, { ...data, updatedAt: new Date() });
  }

  async deleteTask(id: string) {
    const docRef = doc(this.firestore, `${this.collectionName}/${id}`);
    return deleteDoc(docRef);
  }
}
