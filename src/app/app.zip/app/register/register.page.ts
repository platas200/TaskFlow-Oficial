import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // Directivas estándar de Angular como *ngIf.
import { FormsModule } from '@angular/forms'; // Habilita el uso de formularios y [(ngModel)].
import { IonicModule } from '@ionic/angular'; // Carga los componentes visuales de Ionic.
import { Router, RouterLink } from '@angular/router'; // Herramientas para cambiar de pantalla.
import { AlertController, LoadingController } from '@ionic/angular'; // Controladores para alertas y pantallas de carga.

@Component({
  selector: 'app-register', // Nombre de la etiqueta para usar este componente.
  templateUrl: './register.page.html', // Ruta al archivo de estructura.
  styleUrl: './register.page.scss', // Ruta al archivo de estilos.
  standalone: true, // Indica que no depende de un módulo externo (NgModules).
  imports: [IonicModule, CommonModule, FormsModule, RouterLink,] // Módulos necesarios para que funcione la vista.
})
export class RegisterPage {
  // Variable que almacena el rol seleccionado. Por defecto es 'colaborador'.
  rol: string = 'colaborador';

  // Inyectamos las herramientas necesarias en el constructor.
  constructor(
    private router: Router, // Para movernos a Tab1.
    private loadingCtrl: LoadingController, // Para mostrar el spinner de "Creando cuenta".
    private alertCtrl: AlertController // Para mostrar alertas si fuera necesario.
  ) {}

 // Función principal para procesar el registro del usuario.
 async registrarUsuario() {
  // Creamos y configuramos el mensaje de carga visual.
  const loading = await this.loadingCtrl.create({
    message: 'Creando cuenta...',
    duration: 1500 // Se cerrará automáticamente tras 1.5 segundos.
  });
  await loading.present(); // Muestra el mensaje en pantalla.

  /** * PERSISTENCIA LOCAL:
   * Guardamos el rol en la memoria del navegador/teléfono. 
   * Esto es lo que permite que Tab1 sepa si debe mostrar botones de Líder o no.
   */
  localStorage.setItem('userRol', this.rol); 

  // Registro en consola para depuración técnica.
  console.log('Usuario registrado y guardado como:', this.rol);

  // Esperamos a que el mensaje de carga termine para navegar.
  setTimeout(() => {
    // Redirección a la pestaña principal de la aplicación.
    this.router.navigate(['/tabs/tab1']);
  }, 1500);
}

// Función simple para volver a la pantalla de acceso.
irALogin() {
  this.router.navigate(['/login']);
}
}