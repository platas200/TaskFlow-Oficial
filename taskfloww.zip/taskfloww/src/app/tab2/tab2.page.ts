import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Firestore, collection, addDoc } from '@angular/fire/firestore';
import { ToastController } from '@ionic/angular'; 
// Importaciones necesarias para el cierre de sesión
import { Auth, signOut } from '@angular/fire/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: true,
  imports: [
    FormsModule,
    IonicModule
  ],
})
export class Tab2Page {
  // Variables para conectar con el formulario
  tituloTarea: string = '';
  descripcionTarea: string = '';
  prioridadTarea: string = 'medium';

  private firestore: Firestore = inject(Firestore);
  private auth: Auth = inject(Auth); // Inyectamos Auth
  private router: Router = inject(Router); // Inyectamos Router

  constructor(private toastCtrl: ToastController) {}

  async addTarea() {
    if (this.tituloTarea.trim() === '') {
      const toast = await this.toastCtrl.create({
        message: 'Por favor, ingresa un título',
        duration: 2000,
        color: 'warning'
      });
      toast.present();
      return;
    }

    try {
      const dbRef = collection(this.firestore, 'tareas');
      await addDoc(dbRef, { 
        titulo: this.tituloTarea, 
        descripcion: this.descripcionTarea,
        prioridad: this.prioridadTarea,
        estado: 'En proceso',
        fecha: new Date().toISOString() 
      });

      const toast = await this.toastCtrl.create({
        message: '¡Tarea guardada con éxito!',
        duration: 2000,
        color: 'success'
      });
      toast.present();
      
      this.tituloTarea = '';
      this.descripcionTarea = '';
    } catch (e) {
      console.error("Error al guardar:", e);
    }
  }

  // --- NUEVA FUNCIÓN DE CIERRE DE SESIÓN ---
  async logout() {
    try {
      await signOut(this.auth);
      
      const toast = await this.toastCtrl.create({
        message: 'Sesión cerrada correctamente',
        duration: 1500,
        color: 'light'
      });
      await toast.present();

      // Redirige al login y limpia el historial de navegación
      this.router.navigate(['/login'], { replaceUrl: true });
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
    }
  }
}