import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, IonInput, IonButton } from '@ionic/angular/standalone';
import { Auth } from '@angular/fire/auth';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, getAuth } from 'firebase/auth';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, IonItem, IonLabel, IonInput, IonButton, CommonModule, FormsModule]
})
export class LoginPage implements OnInit {
  email: string = '';
  password: string = '';

  constructor(private router: Router, private auth: Auth) { }

  ngOnInit() {
  }
  login() {
    console.log('login', this.email, this.password);
    console.log('diagnostic getAuth()', getAuth());
    console.log('diagnostic injected auth', this.auth);
    signInWithEmailAndPassword(getAuth(), this.email, this.password)
      .then(() => {
        this.router.navigate(['/tabs/tab1']);
      })
      .catch((err) => {
        console.error('Login error', err);
        alert('Error al iniciar sesión: ' + err.message);
      });
  }

  register() {
    console.log('register', this.email, this.password);
    console.log('diagnostic getAuth()', getAuth());
    console.log('diagnostic injected auth', this.auth);
    createUserWithEmailAndPassword(getAuth(), this.email, this.password)
      .then(() => {
        this.router.navigate(['/tabs/tab1']);
      })
      .catch((err) => {
        console.error('Register error', err);
        alert('Error al crear cuenta: ' + err.message);
      });
  }
}

