import { Component, inject, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common'; // Necesario para el pipe async
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule], // Agrega CommonModule
})
export class Tab1Page implements OnInit {
  tareas$: Observable<any[]> | undefined;
  private taskService = inject(TaskService);

  constructor() {}

  ngOnInit() {
    // Usamos TaskService para obtener las tareas en tiempo real
    this.tareas$ = this.taskService.getTasks();
  }
}