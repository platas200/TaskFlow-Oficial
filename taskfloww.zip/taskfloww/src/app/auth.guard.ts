import { Injectable, inject } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Auth } from '@angular/fire/auth';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  private auth = inject(Auth);
  private router = inject(Router);

  canActivate(): Promise<boolean> {
    const current = this.auth.currentUser;
    if (current) return Promise.resolve(true);

    return new Promise<boolean>((resolve) => {
      // onAuthStateChanged from firebase/auth ensures we wait for initialization
      import('firebase/auth').then(({ onAuthStateChanged }) => {
        onAuthStateChanged(this.auth as any, (user) => {
          if (user) resolve(true);
          else {
            this.router.navigate(['/login']);
            resolve(false);
          }
        });
      }).catch(() => {
        this.router.navigate(['/login']);
        resolve(false);
      });
    });
  }
}
